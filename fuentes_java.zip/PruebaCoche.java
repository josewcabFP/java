package tema9_genericos;

public class PruebaCoche {

	public static void main(String[] args) {
		Coche c = new Coche("azul");
		c.acelera();
		c.acelera();
		System.out.println(c);
	}
}
