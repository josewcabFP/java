package supermercado;

/**
 * Clase que prueba el supermercado.
 * 
 * @author Jose Cabrera, Daniel Nevado
 *
 */

public class TestSupermercado {

	public static void main(String[] args) {
		Supermercado s = new Supermercado();
		
		s.menuPrincipal();

	}

}
