package Ej14_ED;

public class TestFecha {

	public static void main(String[] args) {
		Fecha fech1 = new Fecha(4, 3, 1991); //mayor
		Fecha fech2 = new Fecha(5, 4, 1990);
		
		fech1.diferencia(fech2);

	}

}
